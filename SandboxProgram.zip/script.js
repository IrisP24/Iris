document.addEventListener('DOMContentLoaded', function() {
    const truth = [
    "When was the last time you lied?",
    "When was the last time you cried and why?",
    "What's your biggest fear?",
    "What's your biggest fantasy?",
    "What's a secret you've never told anyone?",
    "Who was your first celebrity crush?",
    "If you were going to be on a reality TV show, which would it be?",
    "What's one thing you hate people knowing about you?",
    "What's the biggest misconception about you?",
    "What's one thing you wish people knew about you?",
    "How would you rate your looks on a scale of 1 to 10?",
    "If you could do any job in the world, what would it be?",
    "What is your love language?",
    "What's something you really hope your family never finds out about?",
    "If you could take one person with you to a deserted island, who would it be?",
    "Have you ever had an imaginary friend?",
    "What's one thing you only do when you're alone?",
    "What gives you the ick?",
    "What's the most surprising thing in your bag right now?",
    "Have you ever stayed friends with someone because it benefitted you beyond the friendship?",
    "Have you ever said something you regret about someone in this room?",
    "What's one thing you wished you've lied about?",
    "What's the biggest mistake you've made in your life?",
    "What's the most illegal thing you've ever done?",
    "If you could change one thing about yourself, what would it be?",
    "What's the most embarrassing thing you've ever done?",
    "Have you ever stolen anything?",
    "What's the worst thing you've ever said to someone?",
    "If you could erase one past experience, what would it be?",
    "What's the most childish thing you still do?",
    "Have you ever cheated in an exam?",
    "What's the most hurtful thing someone has said to you?",
    "Have you ever broken someone's heart?",
    "Do you believe in love at first sight?",
    "Have you ever ghosted someone and why?",
    "Have you ever been ghosted? How did it feel?",
    "What is the craziest thing you've ever done?",
    "What's the worst habit you have?",
    "What's your most shallow reason for not going on a second date?",
    "Have you ever had a one-night stand?",
    "What's the most embarrassing thing that's happened to you in front of a crush?",
    "Have you ever had a crush on a friend's partner?",
    "What's the worst lie you've ever told a partner?",
    "What's your longest relationship?",
    "Have you ever been caught lying?",
    "Have you ever stalked someone on social media?",
    "Have you ever told a secret you promised to keep?",
    "Have you ever told someone you love them when you didn't mean it?",
    "What's the most trouble you've been in?",
    "What's the most uncomfortable date you've ever been on?",
    "What's your weirdest pet peeve?",
    "What's the biggest deal-breaker for you?",
    "What's the meanest thing you've ever done?",
    "Have you ever lied to get out of a bad date?",
    "What's the worst date you've ever been on?",
    "Have you ever been attracted to someone in this room?",
    "What's the worst gift you've ever received?",
    "What's the most outrageous thing you've done while drunk?",
    "Have you ever kissed someone of the same sex?",
    "What's the strangest dream you've ever had?",
    "What's your biggest insecurity?",
    "What do you hope your life will look like in 10 years?",
    "If you could be invisible for a day, what would you do?",
    "What's the biggest lie you've told without being caught?",
    "What's the most annoying thing about your best friend?",
    "Have you ever pretended to like a gift?",
    "What's the longest you've gone without showering?",
    "Have you ever lied about your age?",
    "What's your biggest regret?",
    "What's the most awkward thing that's ever happened to you?",
    "What's one talent you wish you had?",
    "Have you ever eavesdropped on a conversation?",
    "What's the worst decision you've made while angry?",
    "Have you ever pretended to be sick to get out of something?",
    "Have you ever peed in a pool?",
    "What was your childhood nickname?",
    "What's a secret you've never told your parents?",
    "What's your biggest pet peeve?",
    "If you had to marry one of your friends, who would it be?",
    "Have you ever cried over someone?",
    "Have you ever had a crush on a teacher?",
    "Have you ever been fired from a job?",
    "What's the most expensive thing you've stolen?",
    "What's the worst food you've ever eaten?",
    "Have you ever faked being sick to skip school?",
    "Have you ever had a crush on a friend's sibling?",
    "What's the worst thing you've said about someone in this room?",
    "Have you ever lied to your boss?",
    "What's the biggest age gap you've had with a partner?",
    "What's the most inappropriate text you've accidentally sent?",
    "Have you ever snooped through someone's phone?",
    "What's the most inappropriate thing you've done in public?",
    "What's your guilty pleasure TV show?",
    "What's the one thing you would never do, even for all the money in the world?",
    "What's your biggest weakness?",
    "Have you ever been in love with two people at the same time?"
];

    const dareButton = document.getElementById('generate-dare');
    const truthButton = document.getElementById('generate-truth');
    const generatedElement = document.getElementById('generated-element');
    
    
    dareButton.addEventListener('click', generateDare);
    truthButton.addEventListener('click', generateTruth);
    
    function generateDare() {
        
    }
    
    function generateTruth() {
        let randomIndex = Math.floor(Math.random() * truth.length);
        let randomTruth = truth[randomIndex];
        console.log(randomTruth);
        generatedElement.innerHTML = randomTruth;
    }
});